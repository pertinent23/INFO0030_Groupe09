var app__modele_8c =
[
    [ "AppModele_t", "structAppModele__t.html", "structAppModele__t" ],
    [ "create_app", "app__modele_8c.html#af878299c0ef458d67c326f1e277b49db", null ],
    [ "destroy_app", "app__modele_8c.html#a62997ecc2fcec4172f2f0e69ec314af0", null ],
    [ "get_current_pieces", "app__modele_8c.html#a1ea0af41424becd41af8f18b26665ffc", null ],
    [ "get_delay", "app__modele_8c.html#a3968fdcc814d18601c5ed7413bc160e3", null ],
    [ "get_grill_height", "app__modele_8c.html#abff9b8d1c192a461f3d5b542fc969288", null ],
    [ "get_grill_width", "app__modele_8c.html#a83c1d17c515b4641bda823f416d08ad3", null ],
    [ "get_pixel", "app__modele_8c.html#ae8a426f5b432eb91ea870a1fe5c05a99", null ],
    [ "get_pixels", "app__modele_8c.html#a0ee6ebf89f5d8120757ad7e688f2290d", null ],
    [ "get_score", "app__modele_8c.html#a267a64ae4c975c952abfa7c2077a5d56", null ],
    [ "set_current_pieces", "app__modele_8c.html#a061d5d5979619ea5bb84526d535c796f", null ],
    [ "set_deplay", "app__modele_8c.html#aa48e32a2f9742d25f8236aafa5ea9258", null ],
    [ "set_pixel", "app__modele_8c.html#a3e8df89b610070846f9e4a35d526750f", null ],
    [ "set_score", "app__modele_8c.html#ad67aec0b3edd0b22e2099ed575db2618", null ]
];