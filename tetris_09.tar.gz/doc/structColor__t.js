var structColor__t =
[
    [ "b", "structColor__t.html#abd922771b58b261e118f9ef953782903", null ],
    [ "g", "structColor__t.html#a2e9da77d5a263f5756f3df8859038989", null ],
    [ "r", "structColor__t.html#a2f55e8153cf321fd14e9d795a3ecc361", null ]
];