var piece__vue_8h =
[
    [ "PieceVue", "piece__vue_8h.html#a8e1aa4827915df681d521cbb516abd3e", null ],
    [ "create_piece_vue", "piece__vue_8h.html#ae6343bdffc37809c1f806d8b14e32827", null ],
    [ "destroy_piece_vue", "piece__vue_8h.html#a08d79c4613cc184a49adf59985463683", null ],
    [ "get_color", "piece__vue_8h.html#a47000fbe7a05bcb3c6a23e71512d1b74", null ],
    [ "get_piece_model", "piece__vue_8h.html#a731eba4e724ad6f570997bb7e170f937", null ],
    [ "modify_piece_model", "piece__vue_8h.html#a51f7ae5e94382592ce44fd144bd8cf8f", null ]
];