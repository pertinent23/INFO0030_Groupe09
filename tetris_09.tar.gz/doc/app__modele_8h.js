var app__modele_8h =
[
    [ "GRILL_CELL_MARGING", "app__modele_8h.html#aa4163a0c4b93506b02eb17fe4e1e38ad", null ],
    [ "GRILL_CELL_SIZE", "app__modele_8h.html#aece2d65fe4adb051ea037d69eaa7cc46", null ],
    [ "GRILL_HEIGHT", "app__modele_8h.html#a419526444749e03f8e272a5704cf32ef", null ],
    [ "GRILL_WIDTH", "app__modele_8h.html#a2ad7eabaec25b13210332f857daa9725", null ],
    [ "WINDOW_HEIGHT", "app__modele_8h.html#a5473cf64fa979b48335079c99532e243", null ],
    [ "WINDOW_WIDTH", "app__modele_8h.html#a498d9f026138406895e9a34b504ac6a6", null ],
    [ "AppModele", "app__modele_8h.html#afe5a38229883f061b7033da8df30db4b", null ],
    [ "create_app", "app__modele_8h.html#af878299c0ef458d67c326f1e277b49db", null ],
    [ "destroy_app", "app__modele_8h.html#a62997ecc2fcec4172f2f0e69ec314af0", null ],
    [ "get_current_pieces", "app__modele_8h.html#a1ea0af41424becd41af8f18b26665ffc", null ],
    [ "get_delay", "app__modele_8h.html#a3968fdcc814d18601c5ed7413bc160e3", null ],
    [ "get_grill_height", "app__modele_8h.html#abff9b8d1c192a461f3d5b542fc969288", null ],
    [ "get_grill_width", "app__modele_8h.html#a83c1d17c515b4641bda823f416d08ad3", null ],
    [ "get_pixel", "app__modele_8h.html#ae8a426f5b432eb91ea870a1fe5c05a99", null ],
    [ "get_pixels", "app__modele_8h.html#a0ee6ebf89f5d8120757ad7e688f2290d", null ],
    [ "get_score", "app__modele_8h.html#a267a64ae4c975c952abfa7c2077a5d56", null ],
    [ "set_current_pieces", "app__modele_8h.html#a061d5d5979619ea5bb84526d535c796f", null ],
    [ "set_deplay", "app__modele_8h.html#aa48e32a2f9742d25f8236aafa5ea9258", null ],
    [ "set_pixel", "app__modele_8h.html#a3e8df89b610070846f9e4a35d526750f", null ],
    [ "set_score", "app__modele_8h.html#ad67aec0b3edd0b22e2099ed575db2618", null ]
];