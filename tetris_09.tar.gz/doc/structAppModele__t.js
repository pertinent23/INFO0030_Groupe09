var structAppModele__t =
[
    [ "current", "structAppModele__t.html#ae6ae784d3ea60354fa51cf3e1603393b", null ],
    [ "delay", "structAppModele__t.html#a4a1fdb36351c9932ad70cfb74099f32f", null ],
    [ "grill", "structAppModele__t.html#a3fa0f261e34c2c553800cb70e846e349", null ],
    [ "height", "structAppModele__t.html#a6ecfa48040cea34cd2f01d86402a695b", null ],
    [ "score", "structAppModele__t.html#a2cf963b3e26dd238a73dd77385f39144", null ],
    [ "width", "structAppModele__t.html#ac51afecce501d70c64501558404c6bca", null ]
];