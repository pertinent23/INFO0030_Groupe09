var structPieceModel__t =
[
    [ "angle", "structPieceModel__t.html#a5b0abe8eb925415add2a99e32907eddb", null ],
    [ "gravity", "structPieceModel__t.html#a89bc4cfe2293f0176d3ad7a4dbe6a41d", null ],
    [ "shema", "structPieceModel__t.html#af0adf8c7d5013aeea6eee81c9e3ddba0", null ],
    [ "type", "structPieceModel__t.html#a96c7661f3a7d666562c20d41e0a23656", null ],
    [ "x", "structPieceModel__t.html#a9b9732b4b5826595a1e907707bd20c83", null ],
    [ "y", "structPieceModel__t.html#a8f3a3f4c7ebb261013d9a9aa5dde2dee", null ]
];