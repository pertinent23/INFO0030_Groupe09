var structModalModele__t =
[
    [ "type", "structModalModele__t.html#a24a4a331c5aed45b1eb630e74992c97d", null ],
    [ "username", "structModalModele__t.html#a30c6b322be806606c387434b6b68aa14", null ],
    [ "users", "structModalModele__t.html#aca8df2034e88c1fdcc856d0a61a69553", null ]
];