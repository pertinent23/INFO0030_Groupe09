var searchData=
[
  ['launch_418',['launch',['../app__controleur_8c.html#a895fe600d4160d3be8896722f9cb7189',1,'launch(struct AppControleur_t *app):&#160;app_controleur.c'],['../app__controleur_8h.html#a895fe600d4160d3be8896722f9cb7189',1,'launch(struct AppControleur_t *app):&#160;app_controleur.c']]],
  ['load_5fapp_5fdata_419',['load_app_data',['../app__controleur_8c.html#a30d1e16113e7af6ab0c3f074fcb22907',1,'app_controleur.c']]]
];
