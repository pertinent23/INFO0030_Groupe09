var searchData=
[
  ['column_5fid_549',['COLUMN_ID',['../modal__vue_8c.html#adc29c2ff13d900c2f185ee95427fb06cad42963e993a0d76e1a2511cf50b17c79',1,'modal_vue.c']]],
  ['column_5fpseudo_550',['COLUMN_PSEUDO',['../modal__vue_8c.html#adc29c2ff13d900c2f185ee95427fb06cad64d154a7337d506942eb2ed15509fe0',1,'modal_vue.c']]],
  ['column_5fscore_551',['COLUMN_SCORE',['../modal__vue_8c.html#adc29c2ff13d900c2f185ee95427fb06ca717208f182d19bb0f293d7951b0fb6e5',1,'modal_vue.c']]]
];
