var searchData=
[
  ['b_469',['b',['../structColor__t.html#abd922771b58b261e118f9ef953782903',1,'Color_t']]],
  ['best_470',['best',['../structAppVue__t.html#a036639724bbcf12b1c4e5ff6b9640eb0',1,'AppVue_t']]],
  ['blue_471',['BLUE',['../tools_8c.html#a6391b7ef6517170e07a1011955f8cb5b',1,'BLUE():&#160;tools.c'],['../tools_8h.html#a6391b7ef6517170e07a1011955f8cb5b',1,'BLUE():&#160;tools.c']]],
  ['button_472',['button',['../structModalVue__t.html#a478e1db9ba9863d6e372a372ac8057a7',1,'ModalVue_t']]],
  ['buttons_473',['buttons',['../structAppVue__t.html#aed85c6bd16d679f44eabd47d7190d670',1,'AppVue_t']]]
];
