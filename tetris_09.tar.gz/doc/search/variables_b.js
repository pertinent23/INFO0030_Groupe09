var searchData=
[
  ['options_505',['options',['../structAppVue__t.html#ab0a3d5c37634ac5d025a427cdf600764',1,'AppVue_t']]],
  ['orange_506',['ORANGE',['../tools_8c.html#add78a7d6cbfe8692a87e06018f460962',1,'ORANGE():&#160;tools.c'],['../tools_8h.html#add78a7d6cbfe8692a87e06018f460962',1,'ORANGE():&#160;tools.c']]]
];
