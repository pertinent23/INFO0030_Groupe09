var searchData=
[
  ['pause_507',['pause',['../structAppControleur__t.html#a0f35a5fb9f3ae397127590c32d7ddbfa',1,'AppControleur_t']]],
  ['play_508',['play',['../structAppControleur__t.html#ae5545aedb539ae20b08e201091b1efbf',1,'AppControleur_t']]],
  ['prev_509',['prev',['../structModaleUser__t.html#a16be28b0a800cfd73a4a701c270af56c',1,'ModaleUser_t']]],
  ['purple_510',['PURPLE',['../tools_8c.html#affc18469465ae2e84a6929a2c541fef5',1,'PURPLE():&#160;tools.c'],['../tools_8h.html#affc18469465ae2e84a6929a2c541fef5',1,'PURPLE():&#160;tools.c']]]
];
