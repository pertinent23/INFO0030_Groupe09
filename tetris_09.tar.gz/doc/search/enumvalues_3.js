var searchData=
[
  ['num_5fcolumns_554',['NUM_COLUMNS',['../modal__vue_8c.html#adc29c2ff13d900c2f185ee95427fb06ca94a1900486855d9c85622e2c106104a9',1,'modal_vue.c']]]
];
