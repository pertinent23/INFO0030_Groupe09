var searchData=
[
  ['color_5ft_291',['Color_t',['../structColor__t.html',1,'']]]
];
