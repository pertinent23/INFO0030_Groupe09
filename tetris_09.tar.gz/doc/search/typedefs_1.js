var searchData=
[
  ['color_533',['Color',['../tools_8h.html#aac3e3306c8d6fa35e52811dc72029204',1,'tools.h']]]
];
