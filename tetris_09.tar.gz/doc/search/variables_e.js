var searchData=
[
  ['r_512',['r',['../structColor__t.html#a2f55e8153cf321fd14e9d795a3ecc361',1,'Color_t']]],
  ['red_513',['RED',['../tools_8c.html#a25bf35508bcb86a7834ba0b0dde0bf9f',1,'RED():&#160;tools.c'],['../tools_8h.html#a25bf35508bcb86a7834ba0b0dde0bf9f',1,'RED():&#160;tools.c']]],
  ['round_514',['round',['../structAppVue__t.html#ae09b7228f1e4c5d3252f688d9660d14d',1,'AppVue_t']]]
];
