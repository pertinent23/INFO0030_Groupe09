var searchData=
[
  ['new_193',['new',['../structAppVue__t.html#a3f14f0e6e60b87e004710565486e2204',1,'AppVue_t']]],
  ['new_5fgame_194',['new_game',['../app__controleur_8c.html#a8eca24c35b3033a8c665164b507250aa',1,'app_controleur.c']]],
  ['new_5fmodal_195',['new_modal',['../modal__controleur_8c.html#a8a3f58c033365a95ffd945f4554fe46e',1,'new_modal(ModalType type):&#160;modal_controleur.c'],['../modal__controleur_8h.html#a8a3f58c033365a95ffd945f4554fe46e',1,'new_modal(ModalType type):&#160;modal_controleur.c']]],
  ['next_196',['next',['../structModaleUser__t.html#aa49c6e70346ef1fed38e4cb4a7dc3237',1,'ModaleUser_t']]],
  ['num_5fcolumns_197',['NUM_COLUMNS',['../modal__vue_8c.html#adc29c2ff13d900c2f185ee95427fb06ca94a1900486855d9c85622e2c106104a9',1,'modal_vue.c']]]
];
