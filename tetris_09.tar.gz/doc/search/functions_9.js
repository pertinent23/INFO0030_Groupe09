var searchData=
[
  ['new_5fgame_426',['new_game',['../app__controleur_8c.html#a8eca24c35b3033a8c665164b507250aa',1,'app_controleur.c']]],
  ['new_5fmodal_427',['new_modal',['../modal__controleur_8c.html#a8a3f58c033365a95ffd945f4554fe46e',1,'new_modal(ModalType type):&#160;modal_controleur.c'],['../modal__controleur_8h.html#a8a3f58c033365a95ffd945f4554fe46e',1,'new_modal(ModalType type):&#160;modal_controleur.c']]]
];
