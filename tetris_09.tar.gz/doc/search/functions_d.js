var searchData=
[
  ['update_5fdelay_5flabel_459',['update_delay_label',['../app__vue_8c.html#ac0635271c27b3dcfde8a53c8aa45499f',1,'update_delay_label(struct AppVue_t *vue):&#160;app_vue.c'],['../app__vue_8h.html#ac0635271c27b3dcfde8a53c8aa45499f',1,'update_delay_label(struct AppVue_t *vue):&#160;app_vue.c']]],
  ['update_5fgravity_460',['update_gravity',['../piece__modele_8c.html#a7a2711d8cca3ae408b81e3a47d9f9e81',1,'update_gravity(struct PieceModel_t *piece):&#160;piece_modele.c'],['../piece__modele_8h.html#a7a2711d8cca3ae408b81e3a47d9f9e81',1,'update_gravity(struct PieceModel_t *piece):&#160;piece_modele.c']]],
  ['update_5fscore_5flabel_461',['update_score_label',['../app__vue_8c.html#af287f15859a7f154934f332150e327f2',1,'update_score_label(struct AppVue_t *vue):&#160;app_vue.c'],['../app__vue_8h.html#af287f15859a7f154934f332150e327f2',1,'update_score_label(struct AppVue_t *vue):&#160;app_vue.c']]]
];
