var searchData=
[
  ['new_503',['new',['../structAppVue__t.html#a3f14f0e6e60b87e004710565486e2204',1,'AppVue_t']]],
  ['next_504',['next',['../structModaleUser__t.html#aa49c6e70346ef1fed38e4cb4a7dc3237',1,'ModaleUser_t']]]
];
