var searchData=
[
  ['add_5fscore_320',['add_score',['../app__controleur_8c.html#a9172cc70139cc0d0ccf01a67a0c81e18',1,'app_controleur.c']]],
  ['add_5fuser_321',['add_user',['../modal__modele_8c.html#ad06d6153c918dfe1572007c197fb8d31',1,'add_user(struct ModalModele_t *modal, ModalUser *user):&#160;modal_modele.c'],['../modal__modele_8h.html#ad06d6153c918dfe1572007c197fb8d31',1,'add_user(struct ModalModele_t *modal, ModalUser *user):&#160;modal_modele.c']]],
  ['add_5fusers_322',['add_users',['../modal__vue_8c.html#ad0a6fd2f1047b79494e5cd7a9451da96',1,'add_users(struct ModalVue_t *modal):&#160;modal_vue.c'],['../modal__vue_8h.html#ad0a6fd2f1047b79494e5cd7a9451da96',1,'add_users(struct ModalVue_t *modal):&#160;modal_vue.c']]],
  ['arrow_5fdown_5fpressed_323',['arrow_down_pressed',['../app__controleur_8c.html#aadadfe74318edeb654488f2a9864260a',1,'app_controleur.c']]],
  ['arrow_5fleft_5fpressed_324',['arrow_left_pressed',['../app__controleur_8c.html#a84e5851c40dd4f484acd70a92eea74a6',1,'app_controleur.c']]],
  ['arrow_5fright_5fpressed_325',['arrow_right_pressed',['../app__controleur_8c.html#ae41dbccc977e7b18d1e8f9e44f66cecc',1,'app_controleur.c']]],
  ['arrow_5fup_5fpressed_326',['arrow_up_pressed',['../app__controleur_8c.html#a758a7efb638a178996d4d1127e5fd4a6',1,'app_controleur.c']]]
];
