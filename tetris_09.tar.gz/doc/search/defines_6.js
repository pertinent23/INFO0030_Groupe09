var searchData=
[
  ['window_5fheight_576',['WINDOW_HEIGHT',['../app__modele_8h.html#a5473cf64fa979b48335079c99532e243',1,'app_modele.h']]],
  ['window_5fwidth_577',['WINDOW_WIDTH',['../app__modele_8h.html#a498d9f026138406895e9a34b504ac6a6',1,'app_modele.h']]]
];
