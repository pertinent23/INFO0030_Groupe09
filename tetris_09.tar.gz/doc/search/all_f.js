var searchData=
[
  ['r_231',['r',['../structColor__t.html#a2f55e8153cf321fd14e9d795a3ecc361',1,'Color_t']]],
  ['read_5fscore_232',['read_score',['../app__controleur_8c.html#a03fa269eddcfb68144c395f9a64c9668',1,'app_controleur.c']]],
  ['recenter_233',['recenter',['../piece__modele_8c.html#aaafa9693181d202945998ba734072b71',1,'piece_modele.c']]],
  ['red_234',['RED',['../tools_8c.html#a25bf35508bcb86a7834ba0b0dde0bf9f',1,'RED():&#160;tools.c'],['../tools_8h.html#a25bf35508bcb86a7834ba0b0dde0bf9f',1,'RED():&#160;tools.c']]],
  ['rotate_5fleft_235',['rotate_left',['../piece__modele_8c.html#ac98de98588ce603614f152aba419ab39',1,'rotate_left(struct PieceModel_t *piece):&#160;piece_modele.c'],['../piece__modele_8h.html#ac98de98588ce603614f152aba419ab39',1,'rotate_left(struct PieceModel_t *piece):&#160;piece_modele.c']]],
  ['rotate_5fright_236',['rotate_right',['../piece__modele_8c.html#a8eed5afc0330a1d78c69b307aa093d70',1,'rotate_right(struct PieceModel_t *piece):&#160;piece_modele.c'],['../piece__modele_8h.html#a8eed5afc0330a1d78c69b307aa093d70',1,'rotate_right(struct PieceModel_t *piece):&#160;piece_modele.c']]],
  ['rotation_5flevel_237',['ROTATION_LEVEL',['../piece__modele_8h.html#ae948b423c29b3ec0e14cd09ab958691f',1,'piece_modele.h']]],
  ['round_238',['round',['../structAppVue__t.html#ae09b7228f1e4c5d3252f688d9660d14d',1,'AppVue_t']]]
];
