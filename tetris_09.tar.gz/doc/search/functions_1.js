var searchData=
[
  ['build_5fapp_5fvue_327',['build_app_vue',['../app__vue_8c.html#ac2ce6856eab7bf7fa273e622bcdf1f6e',1,'build_app_vue(struct AppVue_t *vue):&#160;app_vue.c'],['../app__vue_8h.html#ac2ce6856eab7bf7fa273e622bcdf1f6e',1,'build_app_vue(struct AppVue_t *vue):&#160;app_vue.c']]]
];
