var piece__vue_8c =
[
    [ "PieceVue_t", "structPieceVue__t.html", "structPieceVue__t" ],
    [ "create_piece_vue", "piece__vue_8c.html#ae6343bdffc37809c1f806d8b14e32827", null ],
    [ "destroy_piece_vue", "piece__vue_8c.html#a08d79c4613cc184a49adf59985463683", null ],
    [ "get_color", "piece__vue_8c.html#a47000fbe7a05bcb3c6a23e71512d1b74", null ],
    [ "get_piece_model", "piece__vue_8c.html#a731eba4e724ad6f570997bb7e170f937", null ],
    [ "init_color", "piece__vue_8c.html#a3683d295bf25c32ef8ebd63731a48d5c", null ],
    [ "modify_piece_model", "piece__vue_8c.html#a51f7ae5e94382592ce44fd144bd8cf8f", null ]
];