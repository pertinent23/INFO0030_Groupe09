var structModaleUser__t =
[
    [ "next", "structModaleUser__t.html#aa49c6e70346ef1fed38e4cb4a7dc3237", null ],
    [ "prev", "structModaleUser__t.html#a16be28b0a800cfd73a4a701c270af56c", null ],
    [ "score", "structModaleUser__t.html#aabf76f053c50f7e1f97fb5bf66ccb9a1", null ],
    [ "username", "structModaleUser__t.html#afb031993254e26727a55c913faa62934", null ]
];