var tools_8h =
[
    [ "Color_t", "structColor__t.html", "structColor__t" ],
    [ "UNUSED", "tools_8h.html#a86d500a34c624c2cae56bc25a31b12f3", null ],
    [ "Color", "tools_8h.html#aac3e3306c8d6fa35e52811dc72029204", null ],
    [ "create_label", "tools_8h.html#a1d0130843fce0553f28eef78366525f0", null ],
    [ "set_color", "tools_8h.html#adb6ee183c93d26c22e1e19a737da89be", null ],
    [ "set_font_color", "tools_8h.html#a21490eb4a77c61fc431df207b1b31f95", null ],
    [ "BLUE", "tools_8h.html#a6391b7ef6517170e07a1011955f8cb5b", null ],
    [ "CIAN", "tools_8h.html#abeef71cf2f808b5548161106dddf8c0e", null ],
    [ "DARK", "tools_8h.html#a712aef8c9082d60f334f997eabb47e0d", null ],
    [ "GREEN", "tools_8h.html#abef154f5aadd80d55941b223085259c9", null ],
    [ "ORANGE", "tools_8h.html#add78a7d6cbfe8692a87e06018f460962", null ],
    [ "PURPLE", "tools_8h.html#affc18469465ae2e84a6929a2c541fef5", null ],
    [ "RED", "tools_8h.html#a25bf35508bcb86a7834ba0b0dde0bf9f", null ],
    [ "YELLOW", "tools_8h.html#a03efaca6f1b5ba2ff711bfe7b9859641", null ]
];