var structPieceVue__t =
[
    [ "color", "structPieceVue__t.html#aeb566f658c7848401525422b99b82b97", null ],
    [ "modele", "structPieceVue__t.html#a34d179a12a8c793a6703324e3a79de2a", null ]
];